package com.polymorphism;
//10.Show runtime polymorphism by calling overridden methods using superclass reference for:

//Bird class with method fly()
//Subclasses Sparrow, Eagle

public class Bird {
	public void fly() {
		System.out.println("Birds can fly");
	}
}
