package com.polymorphism;
//3.Overload a method named display() to:

//Display a string
//Display an integer
//Display a string and an integer together.

public class DisplayDetails {
	public void display(String s) {
		System.out.print("The String is - ");
		System.out.println(s);
	}

	public void display(int a) {
		System.out.println("THe integer number is " + a);
	}

	public void display(String s, int a) {
		System.out.print(s);
		System.out.println(a);
	}

	public static void main(String[] args) {
		DisplayDetails d = new DisplayDetails();
		d.display("There is an area named Akurdi in pune.");
		d.display(32);
		d.display("The number of students in 1043 java batch are ", 23);
	}
}
