package com.polymorphism;

public class Sparrow extends Bird {
	@Override
	public void fly() {
		System.out.println("sparrow's speed of flying is slower than eagle.");
	}
}
