package com.polymorphism;

public class Eagle extends Bird {
	@Override
	public void fly() {
		System.out.println("Flying speed of eagle is faster than the sparrow.");
	}

	public static void main(String[] args) {
		Eagle e = new Eagle();
		e.fly();

		Sparrow s = new Sparrow();
		s.fly();
	}
}
