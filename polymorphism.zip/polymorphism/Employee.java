package com.polymorphism;
//9.Create a base class Employee with method calculateSalary() and override it in:

//PermanentEmployee class
//ContractEmployee class

public class Employee {
	public void calculateSalary(int salary) {
		System.out.println("The salary is based on the type of Employee");
	}
}
