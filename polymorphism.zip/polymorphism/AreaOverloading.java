package com.polymorphism;
//1.Overload a method area() to calculate:

//Area of a circle
//Area of a rectangle
//Area of a square

public class AreaOverloading {
	public void area(int radius) {
		double areaCircle = 3.14 * radius * radius;
		System.out.println("Area of circle is " + areaCircle);

	}

	public void area(int l, int b) {
		int areaRectangle = l * b;
		System.out.println("Area of Rectangle is " + areaRectangle);
	}

//public void area(int side) error
	public void area(float side) {
		float areaSquare = side * side;
		System.out.println("Area of square is " + areaSquare);

	}

	public static void main(String[] args) {
		AreaOverloading a = new AreaOverloading();
		a.area(21);
		a.area(2, 3);
		a.area(20);
	}
}
