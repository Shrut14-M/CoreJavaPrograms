package com.polymorphism;

public class Cat extends Animal {
	@Override
	public void sound() {
		System.out.println("cat meows");
	}

	public static void main(String[] args) {
		Cat c = new Cat();
		c.sound();

		Dog d = new Dog();
		d.sound();
	}

}
