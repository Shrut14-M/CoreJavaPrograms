package com.polymorphism;

public class ContractEmployee extends Employee {
	public void calculateSalary(int salary) {
		System.out.println("Salary of the Contract based Employee is " + salary);
	}

	public static void main(String[] args) {
		ContractEmployee c = new ContractEmployee();
		c.calculateSalary(15000);

		PermanentEmployee p = new PermanentEmployee();
		p.calculateSalary(40000);
	}
}
