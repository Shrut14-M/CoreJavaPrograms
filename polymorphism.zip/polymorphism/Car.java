package com.polymorphism;

public class Car extends Vehicle {
	@Override
	public void move() {
		System.out.println("The car is moving.");
	}
}
