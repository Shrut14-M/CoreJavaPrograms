package com.polymorphism;
//7.Create a class Vehicle with method move() and override it in:

//Car class → "Car is moving"
//Bike class → "Bike is moving"

public class Vehicle {
	public void move() {
		System.out.println("Vehicles moves from one place to another.");
	}
}
