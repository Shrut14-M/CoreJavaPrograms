package com.polymorphism;
//6.Create a superclass Animal with a method sound() and override it in:

//Subclass Dog → prints "Bark"
//Subclass Cat → prints "Meow"

public class Animal {
	public void sound() {
		System.out.println("Animals makes different kinds of sounds");
	}
}
