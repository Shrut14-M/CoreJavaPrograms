package com.polymorphism;

public class Triangle extends Shape {
	@Override
	public void draw() {
		System.out.println("This is a Triangle.");
	}

	public static void main(String[] args) {
		Circle c = new Circle();
		c.draw();

		Rectangle r = new Rectangle();
		r.draw();

		Triangle t = new Triangle();
		t.draw();

	}
}
