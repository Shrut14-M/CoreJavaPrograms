package com.polymorphism;

public class PermanentEmployee extends Employee {
	@Override
	public void calculateSalary(int salary) {
		System.out.println("Salary of the permanent Employee is " + salary);
	}
}
