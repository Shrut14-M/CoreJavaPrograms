package com.polymorphism;

public class Rectangle extends Shape {
	@Override
	public void draw() {
		System.out.println("This is a Rectangle.");
	}
}
