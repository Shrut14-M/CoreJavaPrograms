package com.polymorphism;
//8.Create a class Shape with method draw() and override it in:

//Circle class
//Rectangle class
//Triangle class

public class Shape {
	public void draw() {
		System.out.println("There are different shapes in Geometry.");
	}
}
