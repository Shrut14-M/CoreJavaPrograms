package com.polymorphism;
//2.Create a Calculator class with overloaded add() methods:

//add(int, int)
//add(double, double)
//add(int, int, int)

public class Calculator {
	public void add(int a, int b) {
		int c = a + b;
		System.out.println("Addition of two variables using int datatype is " + c);
	}

	public void add(double a, double b) {
		double c = a + b;
		System.out.println("Addition of variables using double datatyepe is " + c);
	}

	public void add(int a, int b, int c) {
		int d = a + b + c;
		System.out.println("Addition of three variables using int datatype is " + d);
	}

	public static void main(String[] args) {
		Calculator c = new Calculator();
		c.add(2, 3);
		c.add(5.4, 3.4);
		c.add(1, 2, 5);
	}

}
