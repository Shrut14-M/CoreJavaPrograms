package com.polymorphism;
//4.Write a program to overload a constructor in a Student class:

//Constructor 1: takes no arguments
//Constructor 2: takes roll number
//Constructor 3: takes roll number and name

public class ConstructorOverload {
	public ConstructorOverload() {
		System.out.println("In this constructor there are no arguments present");
	}

	public ConstructorOverload(int rollNo) {
		System.out.println("Roll Number is " + rollNo);
	}

	public ConstructorOverload(String Name, int rollNo) {
		System.out.println("THe name of the Student is " + Name + " whose roll no is " + rollNo);
	}

	public static void main(String[] args) {
		ConstructorOverload c = new ConstructorOverload();
		ConstructorOverload c1 = new ConstructorOverload(21);
		ConstructorOverload c2 = new ConstructorOverload("Shruti", 24);

	}

}
