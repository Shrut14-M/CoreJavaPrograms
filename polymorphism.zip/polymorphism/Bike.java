package com.polymorphism;

public class Bike extends Vehicle {
	@Override
	public void move() {
		System.out.println("The bike is moving.");
	}

	public static void main(String[] args) {
		Bike b = new Bike();
		b.move();

		Car c = new Car();
		c.move();
	}
}
