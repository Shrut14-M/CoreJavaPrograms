package com.polymorphism;
//5.Create a BankAccount class with overloaded deposit() methods:

//deposit(int amount)
//deposit(int amount, String mode) (like "cash", "cheque")

public class BankAccount {
	int balance = 500;

	public void deposit(int amount) {
		int finalBalance;
		finalBalance = balance + amount;
		System.out.println("THe amount deposited is " + amount);
		System.out.println("The total balance in the account is " + finalBalance);

	}

	public void deposit(int amount, String mode) {
		int finalBalance;
		finalBalance = balance + amount;
		System.out.println("The amount deposited is " + amount);
		System.out.println("The total balance in the account is " + finalBalance);
		System.out.println("The mode of deposition of the amount is " + mode);
	}

	public static void main(String[] args) {
		BankAccount b = new BankAccount();
		b.deposit(500);
		System.out.println();
		b.deposit(250, "Cash");
	}
}
