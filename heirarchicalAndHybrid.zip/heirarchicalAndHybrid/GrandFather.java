package com.heirarchicalAndHybrid;

public class GrandFather {
	String prop = "50cr";

	public void inherit() {
		System.out.println("Grandfather inherits the property to its childs which is " + prop);
	}
}
