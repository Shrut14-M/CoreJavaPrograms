package com.heirarchicalAndHybrid;

public class Circle extends Shape {
public void areaOfCircle() {
	double a = 3.14*radius*radius;
	System.out.println("Area of the circle is "+a);
}
}