package com.heirarchicalAndHybrid;

public class Employee extends Person {
public void employee() {
	System.out.println("Profession of this person is Employee");
}
}
