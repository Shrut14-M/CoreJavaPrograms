package com.heirarchicalAndHybrid;

public class Triangle extends Shape {
public void areaOfTriangle() {
	double c= 0.5*breadth*heigth;
	System.out.println("Area of Triangle is "+c);
}

public static void main(String[] args) {
	Shape s= new Shape();
	s.measurements(10, 20, 15, 4);
	
	Circle c= new Circle();
	c.areaOfCircle();
	
	Rectangle r= new Rectangle();
	r.areaOfRectangle();
	
	Triangle t= new Triangle();
	t.areaOfTriangle();

}
}
