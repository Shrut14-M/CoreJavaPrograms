package com.heirarchicalAndHybrid;

public class Daughter extends Aunt{
public void daughter() {
	System.out.println("Daughter extends property of Aunt as well as grandfather");
}

public static void main(String[] args) {
	GrandFather g= new GrandFather();
	g.inherit();
	System.out.println();
	
	
	Father f= new Father();
	//f.inherit();
	f.father();
	
	
	Uncle u= new Uncle();
	//u.inherit();
	u.uncle();
	
	
	Aunt a= new Aunt() ;
	//a.inherit();
	a.aunt();
	System.out.println();
	
	System.out.println("It's a hierarchical Inheritance");
	
	System.out.println();
	
	Father f1= new Father();
	//f.inherit();
	f.father();
	System.out.println("It's a single inheritance");
	System.out.println();
	
	
	
	Daughter d= new Daughter();
	d.daughter();
	d.aunt();
	System.out.println("It's a Multilevel Inheritance");
	System.out.println();
	
	Son s= new Son();
	s.son();
	s.father();
	System.out.println("It's a Multilevel Inheritance");
	
	
	
}
}
