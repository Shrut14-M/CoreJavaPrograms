package com.heirarchicalAndHybrid;

public class Student extends Person {
public void student() {
	System.out.println("Profession of this person is Student");
}
}
