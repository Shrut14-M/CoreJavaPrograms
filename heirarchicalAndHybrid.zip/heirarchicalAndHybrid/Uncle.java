package com.heirarchicalAndHybrid;

public class Uncle extends GrandFather{
	public void uncle() {
		System.out.println("Uncle extends Grandfathers property");
	}
}
