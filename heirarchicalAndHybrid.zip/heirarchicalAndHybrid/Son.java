package com.heirarchicalAndHybrid;

public class Son extends Father{
String prop3 = "50lacs";

public void son() {
	System.out.println("Son has access of Fathers property also grandfathers property as well as his own which is "+prop3);
	
}
}
