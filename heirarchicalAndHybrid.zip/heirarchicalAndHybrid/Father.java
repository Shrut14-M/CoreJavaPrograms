package com.heirarchicalAndHybrid;

public class Father extends GrandFather {
	String prop1 = "10cr";

	public void father() {
		System.out.println(
				"Father inherits the property of grandpa as well as he have his own property which is " + prop1);
	}
}
