package com.heirarchicalAndHybrid;

public class Animal {
public void makeSound() {
	System.out.println("Animals makes different sounds");
}
}
