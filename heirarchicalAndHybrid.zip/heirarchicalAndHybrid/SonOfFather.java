package com.heirarchicalAndHybrid;

public class SonOfFather extends FatherOfson{
public void showSon() {
	System.out.println("Son inherits the property of father as well as grandfather");
	
}
public static void main(String[] args) {
	SonOfFather s= new SonOfFather();
	s.showGrandfather();
	
	s.showfather();
	
	s.showSon();
}
}
