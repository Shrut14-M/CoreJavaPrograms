package com.heirarchicalAndHybrid;

public class GrandPa {
public void showGrandfather() {
	System.out.println("grandfather inherits the property to his child");
}
}
