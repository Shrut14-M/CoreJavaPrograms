package com.heirarchicalAndHybrid;

public class Person {
public void person() {
	System.out.println("What is the Profession of this Person?");
}
public static void main(String[] args) {
	Employee e= new Employee();
	e.person();
	e.employee();
	System.out.println();
	
	Student s= new Student();
	s.person();
	s.student();
}
}
