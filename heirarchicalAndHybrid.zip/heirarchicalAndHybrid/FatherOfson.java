package com.heirarchicalAndHybrid;

public class FatherOfson extends GrandPa{
public void showfather() {
	System.out.println("Father got the property from grandfather");
}
}
