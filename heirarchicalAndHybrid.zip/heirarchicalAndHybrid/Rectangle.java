package com.heirarchicalAndHybrid;

public class Rectangle extends Shape {
public void areaOfRectangle() {
	int b= length*breadth;
	System.out.println("Area of Rectangle is "+b);
	
}
}
