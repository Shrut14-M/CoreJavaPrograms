package com.heirarchicalAndHybrid;

public class Shape {
	int	radius=12;
	int length=20;
	int breadth=10;
	int heigth=5;
public void measurements(int radius,int length, int breadth, int heigth) {
	this.radius=radius;
	this.length=length;
	this.breadth=breadth;
	this.heigth=heigth;

	System.out.println("by using the measurements perform the further operations");
}
}
