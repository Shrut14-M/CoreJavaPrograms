package com.heirarchicalAndHybrid;

public class Aunt extends GrandFather {
String prop2= "95lacs";

public void aunt() {
	System.out.println("Aunt have her own property of "+prop2);
	System.out.println("also she got inherited from Grandfather");
}
}
