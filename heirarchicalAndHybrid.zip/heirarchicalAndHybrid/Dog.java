package com.heirarchicalAndHybrid;

public class Dog extends Animal {
public void dog() {
	System.out.println("Dog barks");
}
public static void main(String[] args) {
	Dog d= new Dog();
	d.makeSound();
	d.dog();
}
}
